var searchData=
[
  ['factoryresetting',['FactoryResetting',['../interface_captuvo.html#ab4dbd31642a477358a0e8e5adbe3bd67',1,'Captuvo']]]
];
