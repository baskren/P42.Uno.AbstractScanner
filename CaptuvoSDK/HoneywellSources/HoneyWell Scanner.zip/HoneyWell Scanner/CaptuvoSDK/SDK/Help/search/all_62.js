var searchData=
[
  ['batterystatusadapter',['BatteryStatusAdapter',['../interface_battery_status_adapter.html',1,'']]],
  ['batterystatusadapter_28_29',['BatteryStatusAdapter()',['../category_battery_status_adapter_07_08.html',1,'']]],
  ['batterystatuscaptuvo',['BatteryStatusCaptuvo',['../interface_battery_status_captuvo.html',1,'']]],
  ['batterystatuscaptuvo_28_29',['BatteryStatusCaptuvo()',['../category_battery_status_captuvo_07_08.html',1,'']]],
  ['batterystatuscupertino',['BatteryStatusCupertino',['../interface_battery_status_cupertino.html',1,'']]],
  ['batterystatuscupertino_28_29',['BatteryStatusCupertino()',['../category_battery_status_cupertino_07_08.html',1,'']]],
  ['batterystatusmanagerprotocol_2dp',['BatteryStatusManagerProtocol-p',['../protocol_battery_status_manager_protocol-p.html',1,'']]],
  ['batterystatusprotocol_2dp',['BatteryStatusProtocol-p',['../protocol_battery_status_protocol-p.html',1,'']]]
];
