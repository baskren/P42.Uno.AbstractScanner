var searchData=
[
  ['honeywell_5favailable_5fcaptuvo',['HONEYWELL_AVAILABLE_CAPTUVO',['../interface_captuvo.html#af7b64a23be53da44c747f2bb39620c53',1,'Captuvo']]],
  ['honeywell_5fdeprecated_5fcaptuvo',['HONEYWELL_DEPRECATED_CAPTUVO',['../interface_captuvo.html#ad155b6046768d718d774518e9d0e0381',1,'Captuvo::HONEYWELL_DEPRECATED_CAPTUVO()'],['../interface_captuvo.html#ad155b6046768d718d774518e9d0e0381',1,'Captuvo::HONEYWELL_DEPRECATED_CAPTUVO()']]]
];
