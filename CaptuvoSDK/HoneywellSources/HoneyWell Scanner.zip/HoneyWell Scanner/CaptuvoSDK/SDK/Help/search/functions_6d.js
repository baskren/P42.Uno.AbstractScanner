var searchData=
[
  ['movetorunloop_3a',['moveToRunLoop:',['../interface_async_socket.html#a0fdb9958e17442b4c6ab13e61b988a15',1,'AsyncSocket']]],
  ['msrcurrentsecuritylevel_3avaliddata_3a',['msrCurrentSecurityLevel:validData:',['../protocol_captuvo_events_protocol-p.html#a475dd79117385148ee710965369d8047',1,'CaptuvoEventsProtocol-p']]],
  ['msrcurrenttrackselection_3avaliddata_3a',['msrCurrentTrackSelection:validData:',['../protocol_captuvo_events_protocol-p.html#a1dbf17a2df231184c62e3f1c18c272f1',1,'CaptuvoEventsProtocol-p']]],
  ['msrfirewareversion_3avaliddata_3a',['msrFirewareVersion:validData:',['../protocol_captuvo_events_protocol-p.html#af482192997471117a8432491089810b3',1,'CaptuvoEventsProtocol-p']]],
  ['msrpassthrough_3aexpectingreturndata_3a',['msrPassThrough:expectingReturnData:',['../interface_captuvo.html#a0a806a2eb804a8da5cc3afca0b9dd0f8',1,'Captuvo']]],
  ['msrpassthroughreturndata_3a',['msrPassThroughReturnData:',['../protocol_captuvo_events_protocol-p.html#a96d81b6c53c30d2279270dc382d02249',1,'CaptuvoEventsProtocol-p::msrPassThroughReturnData:()'],['../protocol_captuvo_private_events_protocol-p.html#ad2410e90192bbde8062a1499086cd432',1,'CaptuvoPrivateEventsProtocol-p::msrPassThroughReturnData:()']]],
  ['msrrawdatareceived_3avaliddata_3a',['msrRawDataReceived:validData:',['../protocol_captuvo_events_protocol-p.html#afbc5946ec18cb4b98034099bec7f4627',1,'CaptuvoEventsProtocol-p']]],
  ['msrready',['msrReady',['../protocol_captuvo_events_protocol-p.html#ad03417dd2bfa996deda137dedc5c6a07',1,'CaptuvoEventsProtocol-p']]],
  ['msrserialnumber_3avaliddata_3a',['msrSerialNumber:validData:',['../protocol_captuvo_events_protocol-p.html#acd72b350bee325fa078f676f2bf2ca8f',1,'CaptuvoEventsProtocol-p']]],
  ['msrstringdatareceived_3avaliddata_3a',['msrStringDataReceived:validData:',['../protocol_captuvo_events_protocol-p.html#a5757114635d6d5c66a79dfd052d491ab',1,'CaptuvoEventsProtocol-p']]]
];
