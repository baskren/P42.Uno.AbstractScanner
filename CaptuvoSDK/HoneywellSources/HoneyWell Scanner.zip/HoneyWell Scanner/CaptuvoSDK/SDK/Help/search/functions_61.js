var searchData=
[
  ['acceptoninterface_3aport_3aerror_3a',['acceptOnInterface:port:error:',['../interface_async_socket.html#a64ff98833c4cc29e2572a4ab1cba478b',1,'AsyncSocket']]],
  ['acceptonport_3aerror_3a',['acceptOnPort:error:',['../interface_async_socket.html#a31629074c232524e0edcdc639ce6e747',1,'AsyncSocket']]],
  ['activatehid',['activateHID',['../interface_captuvo.html#a8c448f2221a5ad1017186aef68f1908e',1,'Captuvo']]],
  ['addcaptuvodelegate_3a',['addCaptuvoDelegate:',['../interface_captuvo.html#a96da9ecefb60d56c6c8909f1e6c4744f',1,'Captuvo']]]
];
