/*======================================================================
 
 UNLESS OTHERWISE AGREED TO IN A SIGNED WRITING BY HONEYWELL INTERNATIONAL INC
 (“HONEYWELL”) AND THE USER OF THIS CODE, THIS CODE AND INFORMATION IS PROVIDED
 "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS
 FOR A PARTICULAR PURPOSE.
 
 COPYRIGHT (C) 2008 HONEYWELL INTERNATIONAL INC.
 
 THIS SOFTWARE IS PROTECTED BY COPYRIGHT LAWS OF THE UNITED STATES OF
 AMERICA AND OF FOREIGN COUNTRIES. THIS SOFTWARE IS FURNISHED UNDER A
 LICENSE AND/OR A NONDISCLOSURE AGREEMENT AND MAY BE USED IN ACCORDANCE
 WITH THE TERMS OF THOSE AGREEMENTS. UNAUTHORIZED REPRODUCTION,  DUPLICATION
 OR DISTRIBUTION OF THIS SOFTWARE, OR ANY PORTION OF IT  WILL BE PROSECUTED
 TO THE MAXIMUM EXTENT POSSIBLE UNDER THE LAW.
 
 ======================================================================*/

//
//  PMVC.h
//  SDKTest
//

#import <UIKit/UIKit.h>
#import "Captuvo.h"

@interface PMVC : UIViewController <CaptuvoEventsProtocol,UITextFieldDelegate>
@property (strong, nonatomic) IBOutlet UILabel *chargeStatusLabel;
@property (strong, nonatomic) IBOutlet UILabel *batteryStatusLabel;
@property (strong, nonatomic) IBOutlet UILabel *currentiApplebattery ;
@property (strong, nonatomic) UIDevice *device ;
@property (strong, nonatomic) IBOutlet UISwitch *swichbtn ; 
@property (strong, nonatomic) IBOutlet UILabel *hid_scanKeystatus ;
@property (strong, nonatomic) IBOutlet UIScrollView *scrolview ;
@property (strong, nonatomic) IBOutlet UITextField *mintextfield ;
@property (strong, nonatomic) IBOutlet UITextField *maxtextfield ;
@property (strong, nonatomic) IBOutlet UIButton *setthredholdbutton ;

@property (strong, nonatomic) IBOutlet UIButton *batteryTypeButton;
@property (strong, nonatomic) IBOutlet UIButton *batteryAuthButton;
@property (strong, nonatomic) IBOutlet UIButton *queryBatterydetailButton ;
@property (strong, nonatomic) IBOutlet UIButton *setbatterynotificationTimebutton;
@property (strong, nonatomic) IBOutlet UIButton *chargingsettingButton ;
@property (strong, nonatomic) IBOutlet UIButton *queryChargingInfoButton ;

@property (strong, nonatomic) IBOutlet UILabel *currentBatteryTypelbl ;
@property (strong, nonatomic) IBOutlet UILabel *BatteryAuthlbl ;
@property (strong, nonatomic) IBOutlet UILabel *batterydetailInfolbl ;
@property (strong, nonatomic) IBOutlet UILabel *charginginfolbl ;

@property (strong, nonatomic) IBOutlet UITextField *notificationTimesfield ;
@property (strong, nonatomic) IBOutlet UISwitch *chargeEnableswitch ;
@property (strong, nonatomic) IBOutlet UITextField *startchargefield ;
@property (strong, nonatomic) IBOutlet UITextField *stopchargefield ;
@property (strong, nonatomic) IBOutlet UITextField *sledlimitpowerfield ;

@property (strong,nonatomic) IBOutlet UILabel *firmwareheaderinfolbl ;

//Setting HID Timeout
@property (strong, nonatomic)IBOutlet UILabel *timeoutvaluelbl ;
@property (strong, nonatomic)IBOutlet UITextField *timetextfield;
@property (strong, nonatomic)IBOutlet UIButton *queryHIDButton ;
@property (strong, nonatomic)IBOutlet UIButton *setHIDbutton ; 
- (IBAction)forceShutdown:(id)sender;
- (IBAction)enableAction:(id)sender ;
- (IBAction)disableAction:(id)sender ;

- (IBAction)ActivateHID:(id)sender ;
- (IBAction)DeactivateHID:(id)sender ;
- (IBAction)UnlockHID:(id)sender ;
- (IBAction)LockHID:(id)sender ;

- (IBAction)valueChanged:(id)sender ;


- (IBAction)enablefirmware:(id)sender ;
- (IBAction)disablefirmware:(id)sender ;

- (IBAction)setChargeBatteryThreshold:(id)sender ;
- (IBAction)enableTriggerKey:(id)sender ;
- (IBAction)disableTriggerKey:(id)sender ;

- (IBAction)ledDefultScheme:(id)sender ;
- (IBAction)ledoTherScheme:(id)sender ;
- (IBAction)getFirmwareHeaderAction:(id)sender;

- (IBAction)queryHIDTimeoutAction:(id)sender ;
- (IBAction)setHIDTimeoutAction:(id)sender ;

@end
