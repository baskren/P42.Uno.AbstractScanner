/*======================================================================
 
 UNLESS OTHERWISE AGREED TO IN A SIGNED WRITING BY HONEYWELL INTERNATIONAL INC
 (“HONEYWELL”) AND THE USER OF THIS CODE, THIS CODE AND INFORMATION IS PROVIDED
 "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS
 FOR A PARTICULAR PURPOSE.
 
 COPYRIGHT (C) 2008 HONEYWELL INTERNATIONAL INC.
 
 THIS SOFTWARE IS PROTECTED BY COPYRIGHT LAWS OF THE UNITED STATES OF
 AMERICA AND OF FOREIGN COUNTRIES. THIS SOFTWARE IS FURNISHED UNDER A
 LICENSE AND/OR A NONDISCLOSURE AGREEMENT AND MAY BE USED IN ACCORDANCE
 WITH THE TERMS OF THOSE AGREEMENTS. UNAUTHORIZED REPRODUCTION,  DUPLICATION
 OR DISTRIBUTION OF THIS SOFTWARE, OR ANY PORTION OF IT  WILL BE PROSECUTED
 TO THE MAXIMUM EXTENT POSSIBLE UNDER THE LAW.
 
 ======================================================================*/
//
//  ViewController.h
//  SDKTest
//

#import <UIKit/UIKit.h>
#import "Captuvo.h"

@interface DecoderVC : UIViewController <CaptuvoEventsProtocol>

- (IBAction)startDecoderButton:(id)sender;
- (IBAction)stopDecoderButton:(id)sender;
- (IBAction)scanOnButton:(id)sender;
- (IBAction)scanOffButton:(id)sender;
- (IBAction)beepOffButton:(id)sender;
- (IBAction)beepOnButton:(id)sender;
- (IBAction)clickOnButton:(id)sender;
- (IBAction)clickOffButton:(id)sender;
- (IBAction)grbvOff:(id)sender;
- (IBAction)grbvLow:(id)sender;
- (IBAction)grbvHigh:(id)sender;
- (IBAction)grbvMid:(id)sender;
- (IBAction)grbpHigh:(id)sender;
- (IBAction)grbpMid:(id)sender;
- (IBAction)grbpLow:(id)sender;
- (IBAction)erbpHigh:(id)sender;
- (IBAction)erbpMid:(id)sender;
- (IBAction)erbpRazz:(id)sender;
- (IBAction)grbdNormal:(id)sender;
- (IBAction)grbdShort:(id)sender;
- (IBAction)numberBeepsGoodReadAction:(id)sender;
- (IBAction)numberBeepsErrorReadAction:(id)sender;
- (IBAction)grdOff:(id)sender;
- (IBAction)grd1Sec:(id)sender;
- (IBAction)grd5Sec:(id)sender;
- (IBAction)grd30Sec:(id)sender;
- (IBAction)tmNormal:(id)sender;
- (IBAction)tmEnhanced:(id)sender;
- (IBAction)tt1Sec:(id)sender;
- (IBAction)tt30Sec:(id)sender;
- (IBAction)tt100Sec:(id)sender;
- (IBAction)tt5Sec:(id)sender;
- (IBAction)mobileOn:(id)sender;
- (IBAction)mobileOff:(id)sender;
- (IBAction)rbOn:(id)sender;
- (IBAction)rbOff:(id)sender;
- (IBAction)psOn:(id)sender;
- (IBAction)psOff:(id)sender;
- (IBAction)psDefault:(id)sender;
- (IBAction)hpsQR:(id)sender;
- (IBAction)hpsUPC:(id)sender;
- (IBAction)lpsQR:(id)sender;
- (IBAction)lpsUPC:(id)sender;
- (IBAction)hpsCode128:(id)sender;
- (IBAction)lpsCode128:(id)sender;
- (IBAction)pst500MS:(id)sender;
- (IBAction)pst1s:(id)sender;
- (IBAction)pst2s:(id)sender;
- (IBAction)pst3s:(id)sender;
- (IBAction)rbStatus:(id)sender;
- (IBAction)tcStatus:(id)sender;
- (IBAction)pbStatus:(id)sender;
- (IBAction)grbvStatus:(id)sender;
- (IBAction)grbpStatus:(id)sender;
- (IBAction)erbpStatus:(id)sender;
- (IBAction)grbdStatus:(id)sender;
- (IBAction)snobgrStatus:(id)sender;
- (IBAction)snoberStatus:(id)sender;
- (IBAction)grdStatus:(id)sender;
- (IBAction)tmStatus:(id)sender;
- (IBAction)ttoStatus:(id)sender;
- (IBAction)amStatus:(id)sender;
- (IBAction)psStatus:(id)sender;
- (IBAction)hpsStatus:(id)sender;
- (IBAction)lpsStatus:(id)sender;
- (IBAction)pstStatus:(id)sender;
- (IBAction)cOn:(id)sender;
- (IBAction)cOff:(id)sender;
- (IBAction)cStatus:(id)sender;
- (IBAction)ct10:(id)sender;
- (IBAction)ct25:(id)sender;
- (IBAction)ct40:(id)sender;
- (IBAction)ctStatus:(id)sender;
- (IBAction)cb10:(id)sender;
- (IBAction)cb25:(id)sender;
- (IBAction)cb40:(id)sender;
- (IBAction)cbStatus:(id)sender;
- (IBAction)cl10:(id)sender;
- (IBAction)cl25:(id)sender;
- (IBAction)cl40:(id)sender;
- (IBAction)clStatus:(id)sender;
- (IBAction)cr10:(id)sender;
- (IBAction)cr25:(id)sender;
- (IBAction)cr40:(id)sender;
- (IBAction)crStatus:(id)sender;
- (IBAction)decoderRevision:(id)sender;
- (IBAction)driverRevision:(id)sender;
- (IBAction)softwareRevision:(id)sender;
- (IBAction)upcaOff:(id)sender;
- (IBAction)upcaOn:(id)sender;
- (IBAction)ean13On:(id)sender;
- (IBAction)ean13Off:(id)sender;
- (IBAction)upce0On:(id)sender;
- (IBAction)upce0Off:(id)sender;
- (IBAction)ean8On:(id)sender;
- (IBAction)allOn:(id)sender;
- (IBAction)allOff:(id)sender;
- (IBAction)codabarOn:(id)sender;
- (IBAction)codabarOff:(id)sender;
- (IBAction)code39Off:(id)sender;
- (IBAction)code39On:(id)sender;
- (IBAction)interleaved2of5On:(id)sender;
- (IBAction)interleaved2of5Off:(id)sender;
- (IBAction)nec2of5On:(id)sender;
- (IBAction)nec2of5Off:(id)sender;
- (IBAction)code93On:(id)sender;
- (IBAction)code93Off:(id)sender;
- (IBAction)straight2of5On:(id)sender;
- (IBAction)straight2of5Off:(id)sender;
- (IBAction)straight2of5IATAon:(id)sender;
- (IBAction)straight2of5IATAoff:(id)sender;
- (IBAction)matrix2of5On:(id)sender;
- (IBAction)matrix2of5Off:(id)sender;
- (IBAction)code11On:(id)sender;
- (IBAction)code11Off:(id)sender;
- (IBAction)code128On:(id)sender;
- (IBAction)code128Off:(id)sender;
- (IBAction)gs1On:(id)sender;
- (IBAction)gs1Off:(id)sender;
- (IBAction)telepenOn:(id)sender;
- (IBAction)telepenOff:(id)sender;
- (IBAction)msiOn:(id)sender;
- (IBAction)msiOff:(id)sender;
- (IBAction)gs1BDomniOn:(id)sender;
- (IBAction)gs1BDomniOff:(id)sender;
- (IBAction)gs1BDlimitOn:(id)sender;
- (IBAction)gs1BDlimitOff:(id)sender;
- (IBAction)gs1BDexpandedOn:(id)sender;
- (IBAction)gs1BDexpandedOff:(id)sender;
- (IBAction)codablockAOn:(id)sender;
- (IBAction)codablockAOff:(id)sender;
- (IBAction)codablockFOn:(id)sender;
- (IBAction)codablockFOff:(id)sender;
- (IBAction)pdf417On:(id)sender;
- (IBAction)pdf417Off:(id)sender;
- (IBAction)dataMatrixOn:(id)sender;
- (IBAction)dataMatrixOff:(id)sender;
- (IBAction)maxiCodeOn:(id)sender;
- (IBAction)maxiCodeOff:(id)sender;
- (IBAction)aztecOn:(id)sender;
- (IBAction)aztecOff:(id)sender;
- (IBAction)chineseSensibleOn:(id)sender;
- (IBAction)chineseSensibleOff:(id)sender;
- (IBAction)qrCodeOn:(id)sender;
- (IBAction)qrCodeOff:(id)sender;
- (IBAction)tcifOn:(id)sender;
- (IBAction)tcifOff:(id)sender;
- (IBAction)mpdfOn:(id)sender;
- (IBAction)mpdfOff:(id)sender;

- (IBAction)amOff:(id)sender;
- (IBAction)amOn:(id)sender;
- (IBAction)passThough:(id)sender;
- (IBAction)ean8Off:(id)sender;
- (IBAction)obtainEngineSN:(id)sender;


- (void)getEndTime ; 

@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;
@property (strong, nonatomic) IBOutlet UILabel *decoderData;

@property (strong, nonatomic) NSString *passThrougstring ;
@property (nonatomic, assign) uint64_t start_t ;
@property (nonatomic, assign) uint64_t end_t ;



@end
