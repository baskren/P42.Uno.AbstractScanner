/*======================================================================
 
 UNLESS OTHERWISE AGREED TO IN A SIGNED WRITING BY HONEYWELL INTERNATIONAL INC
 (“HONEYWELL”) AND THE USER OF THIS CODE, THIS CODE AND INFORMATION IS PROVIDED
 "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS
 FOR A PARTICULAR PURPOSE.
 
 COPYRIGHT (C) 2008 HONEYWELL INTERNATIONAL INC.
 
 THIS SOFTWARE IS PROTECTED BY COPYRIGHT LAWS OF THE UNITED STATES OF
 AMERICA AND OF FOREIGN COUNTRIES. THIS SOFTWARE IS FURNISHED UNDER A
 LICENSE AND/OR A NONDISCLOSURE AGREEMENT AND MAY BE USED IN ACCORDANCE
 WITH THE TERMS OF THOSE AGREEMENTS. UNAUTHORIZED REPRODUCTION,  DUPLICATION
 OR DISTRIBUTION OF THIS SOFTWARE, OR ANY PORTION OF IT  WILL BE PROSECUTED
 TO THE MAXIMUM EXTENT POSSIBLE UNDER THE LAW.
 
 ======================================================================*/
//
//  PMVC.m
//  SDKTest
//

#import "PMVC.h"
#import "Captuvo+PrivateAPI.h"
//#import "IOPowerSources.h"
//#import "IOPSKeys.h"
@interface PMVC ()

@property (assign,nonatomic)BOOL updating;
-(void)updateLabels;

@end

@implementation PMVC
@synthesize chargeStatusLabel;
@synthesize batteryStatusLabel;
@synthesize updating;
@synthesize currentiApplebattery = _currentiApplebattery;
@synthesize device = _device ;
@synthesize swichbtn = _swichbtn ;
@synthesize hid_scanKeystatus = _hid_scanKeystatus ;
@synthesize scrolview = _scrolview ;
@synthesize mintextfield = _mintextfield ;
@synthesize maxtextfield = _maxtextfield ; 
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
   self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
   if (self) {
      self.title = @"PM Test";
       
           [[Captuvo sharedCaptuvoDevice] addCaptuvoDelegate:self];
   }
   return self;
}

- (void)drawLayerboader:(UIView*)dview
{
    CGColorRef colorref = CGColorCreate(CGColorSpaceCreateDeviceRGB(),(CGFloat[]){0,0,1, 1 });
    [dview.layer setMasksToBounds:YES];
    [dview.layer setCornerRadius:4.0];
    [dview.layer setBorderWidth:1.0];
    [dview.layer setBorderColor:colorref];
}

- (void)viewDidLoad
{
   [super viewDidLoad];

    [self drawLayerboader:self.setthredholdbutton] ;
    [self drawLayerboader:self.batteryTypeButton] ;
    [self drawLayerboader:self.queryBatterydetailButton];
    [self drawLayerboader:self.setbatterynotificationTimebutton];
    [self drawLayerboader:self.chargingsettingButton];
    [self drawLayerboader:self.queryChargingInfoButton] ;
    [self drawLayerboader:self.batteryAuthButton] ;
    [self drawLayerboader:self.queryHIDButton];
    [self drawLayerboader:self.setHIDbutton] ;
    self.updating = NO;

//    self.mintextfield.keyboardType = UIKeyboardTypeNumberPad ;
//    self.maxtextfield.keyboardType = UIKeyboardTypeNumberPad;
    self.mintextfield.delegate = self;
    self.maxtextfield.delegate = self ;
    self.scrolview.frame=self.view.bounds;
    CGFloat version = [[[UIDevice currentDevice] systemVersion] floatValue] ;
    if (isPad) {
        if (version>=7.0) {
            [self.scrolview setContentSize:CGSizeMake(320*2.4, 2.133*1358)];
        }else{
            [self.scrolview setContentSize:CGSizeMake(320*2.4, 2.133*1358)];
        }
    }else{
        if (version>=7.0) {
            [self.scrolview setContentSize:CGSizeMake(320, 1800)];
        }else{
            [self.scrolview setContentSize:CGSizeMake(320, 1600)];
        }
    }

    [self.view addSubview:self.scrolview] ;
    
    self.chargeStatusLabel.text=@"Not charging";
   
    [self updateLabels];
    self.device = [UIDevice currentDevice] ;
    [UIDevice currentDevice].batteryMonitoringEnabled = YES;
    
    [NSTimer scheduledTimerWithTimeInterval:0.125 target:self
                                   selector:@selector(currentBattery:) userInfo:nil repeats:YES] ; 
   
    [self.swichbtn setOn:NO] ; 
   // Do any additional setup after loading the view from its nib.
    
    NSString *resourcePath=[[NSBundle mainBundle] resourcePath];
//    NSString * real63_A3_firmware = [resourcePath stringByAppendingPathComponent:@"Captuvo_63.00A3.NB.r72.b50_Firmware.bin"];

    NSString * real63_B3_firmware = [resourcePath stringByAppendingPathComponent:@"Captuvo_63.00B3.NB.r308.b123_Firmware.bin"];
    
    SledFirmwareHeader*fwB3_header =[[Captuvo sharedCaptuvoDevice] getFirmwareHeader:real63_B3_firmware] ;

//    @property (assign,nonatomic) NSInteger ver;             // Version information indicator, always KEYBRD_INFO_BASE
//    @property (assign,nonatomic) NSInteger size;            // Size in bytes of this structure, always 0x34 byte
//    @property (strong,nonatomic) NSString* version;         // 63.00.NB.r49
//    @property (strong,nonatomic) NSString* type;            // Type of firmware: valid value 'b'/'m'/'u'
//    @property (strong,nonatomic) NSString* date;            // eg."May 14 2004"
//    @property (strong,nonatomic) NSString* time;            // eg."18:00:00"
    
    self.firmwareheaderinfolbl.text = [NSString stringWithFormat:@"ver:%ld\n" ,(long)fwB3_header.ver] ;
    
    self.firmwareheaderinfolbl.text = [NSString stringWithFormat:@"%@size:%ld\n",self.firmwareheaderinfolbl.text, (long)fwB3_header.size] ;

    self.firmwareheaderinfolbl.text = [NSString stringWithFormat:@"%@version:%@\n",self.firmwareheaderinfolbl.text, fwB3_header.version] ;

    self.firmwareheaderinfolbl.text = [NSString stringWithFormat:@"%@type:%@\n",self.firmwareheaderinfolbl.text, fwB3_header.type] ;
    
    self.firmwareheaderinfolbl.text = [NSString stringWithFormat:@"%@date:%@\n",self.firmwareheaderinfolbl.text, fwB3_header.date] ;
    
    self.firmwareheaderinfolbl.text = [NSString stringWithFormat:@"%@time:%@",self.firmwareheaderinfolbl.text, fwB3_header.time] ;
}


- (void)currentBattery:(NSTimer*)timer
{
    
//    self.currentiApplebattery.text = [NSString stringWithFormat:@"iApple Battery:%.0lf%%",[self batteryLevel]] ;
    self.currentiApplebattery.text = [NSString stringWithFormat:@"iPhone/iPod Battery:%.0lf%%",100*[[UIDevice currentDevice] batteryLevel]] ;
}

//- (double) batteryLevel
//{
//    CFTypeRef blob = IOPSCopyPowerSourcesInfo();
//    CFArrayRef sources = IOPSCopyPowerSourcesList(blob);
//    
//    CFDictionaryRef pSource = NULL;
//    const void *psValue;
//    
//    int numOfSources = CFArrayGetCount(sources);
//    if (numOfSources == 0) {
//        DLog(@"Error in CFArrayGetCount");
//        return -1.0f;
//    }
//    
//    for (int i = 0 ; i < numOfSources ; i++)
//    {
//        pSource = IOPSGetPowerSourceDescription(blob, CFArrayGetValueAtIndex(sources, i));
//        if (!pSource) {
//            DLog(@"Error in IOPSGetPowerSourceDescription");
//            return -1.0f;
//        }
//        psValue = (CFStringRef)CFDictionaryGetValue(pSource, CFSTR(kIOPSNameKey));
//        
//        int curCapacity = 0;
//        int maxCapacity = 0;
//        double percent;
//        
//        psValue = CFDictionaryGetValue(pSource, CFSTR(kIOPSCurrentCapacityKey));
//        CFNumberGetValue((CFNumberRef)psValue, kCFNumberSInt32Type, &curCapacity);
//        
//        psValue = CFDictionaryGetValue(pSource, CFSTR(kIOPSMaxCapacityKey));
//        CFNumberGetValue((CFNumberRef)psValue, kCFNumberSInt32Type, &maxCapacity);
//        
//        percent = ((double)curCapacity/(double)maxCapacity * 100.0f);
//        
//        return percent;
//    }
//    return -1.0f;
//}


- (void)viewWillAppear:(BOOL)animated
{

    [[Captuvo sharedCaptuvoDevice] addCaptuvoDelegate:self];
    [[Captuvo sharedCaptuvoDevice] startPMHardware] ;
}

-(void)viewDidDisappear:(BOOL)animated
{
    [[Captuvo sharedCaptuvoDevice] removeCaptuvoDelegate:self];
}

- (void)viewDidUnload
{
    
    
    self.device.batteryMonitoringEnabled = YES;
    
   [self setChargeStatusLabel:nil];
   [self setBatteryStatusLabel:nil];
   [super viewDidUnload];
   // Release any retained subviews of the main view.
   // e.g. self.myOutlet = nil;
   self.updating = NO;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
   return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void)updateLabels{
    
     BatteryStatus BatteryStatus = [[Captuvo sharedCaptuvoDevice]getBatteryStatus];
     
   switch (BatteryStatus) {
      case BatteryStatusPowerSourceConnected:
         self.batteryStatusLabel.text = @"|*AC*|";
         break;
      case BatteryStatus4Of4Bars:
         self.batteryStatusLabel.text = @"|****|";
         break;
      case BatteryStatus3Of4Bars:
         self.batteryStatusLabel.text = @"|*** |";
         break;
      case BatteryStatus2Of4Bars:
         self.batteryStatusLabel.text = @"|**  |";
         break;
      case BatteryStatus1Of4Bars:
         self.batteryStatusLabel.text = @"|*   |";
         break;
      case BatteryStatus0Of4Bars:
         self.batteryStatusLabel.text = @"|    |";
         break;
      case BatteryStatusUndefined:
         self.batteryStatusLabel.text = @"UNDEFINE";
      default:
         break;
   }
   if (!self.updating) {
      double delayInSeconds = 2.0;
      dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
      dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
          [self updateLabels];
      });
   }
   
}

-(void)pmBatteryStatusChange:(BatteryStatus)newBatteryStatus{
   switch (newBatteryStatus) {
      case BatteryStatusPowerSourceConnected:
         self.batteryStatusLabel.text = @"|*AC*|";
         break;
      case BatteryStatus4Of4Bars:
         self.batteryStatusLabel.text = @"|****|";
         break;
      case BatteryStatus3Of4Bars:
         self.batteryStatusLabel.text = @"|*** |";
         break;
      case BatteryStatus2Of4Bars:
         self.batteryStatusLabel.text = @"|**  |";
         break;
      case BatteryStatus1Of4Bars:
         self.batteryStatusLabel.text = @"|*   |";
         break;
      case BatteryStatus0Of4Bars:
         self.batteryStatusLabel.text = @"|    |";
         break;
      case BatteryStatusUndefined:
         self.batteryStatusLabel.text = @"UNDEFINE";
      default:
         break;
   }
}

-(void)pmChargeStatusChange:(ChargeStatus)newChargeStatus{
   switch (newChargeStatus) {
      case ChargeStatusCharging:
         self.chargeStatusLabel.text=@"Charging";
         break;
      case ChargeStatusUndefined:
         self.chargeStatusLabel.text=@"Undefined";
         break;
      case ChargeStatusChargeComplete:
         self.chargeStatusLabel.text=@"Charge complete";
         break;
      case ChargeStatusNotCharging:
         self.chargeStatusLabel.text=@"Not charging";
         break;
      default:
         break;
   }
}
- (IBAction)forceShutdown:(id)sender {
   [[Captuvo sharedCaptuvoDevice] forceBatteryLowShutdown];
}

- (void)pmReady
{
    UIAlertView* alert = [[UIAlertView alloc]initWithTitle:nil
                                                   message:@"pm ready"
                                                  delegate:nil
                                         cancelButtonTitle:@"OK"
                                         otherButtonTitles:nil];
    [alert show];
    
    
}

- (IBAction)enableAction:(id)sender
{
    [[Captuvo sharedCaptuvoDevice] enableBatteryQuery] ;
}
- (IBAction)disableAction:(id)sender
{
    [[Captuvo sharedCaptuvoDevice] disableBatteryQuery] ;
}


- (IBAction)ActivateHID:(id)sender
{
    [[Captuvo sharedCaptuvoDevice] activateHID] ;
}
- (IBAction)DeactivateHID:(id)sender
{
    [[Captuvo sharedCaptuvoDevice] deActivateHID] ;
}
- (IBAction)UnlockHID:(id)sender
{
    [[Captuvo sharedCaptuvoDevice] unLockHIDMode] ;
}
- (IBAction)LockHID:(id)sender
{
    [[Captuvo sharedCaptuvoDevice] lockHIDMode]  ;
}

- (IBAction)requestHIDStatus:(id)sender{
    
    [[Captuvo sharedCaptuvoDevice] requestHIDStatus]  ;
    
}


- (IBAction)setChargeBatteryThreshold:(id)sender
{
    [self.mintextfield resignFirstResponder] ;
    [self.maxtextfield resignFirstResponder] ;
    NSInteger min = 0 ;
    NSInteger max = 0 ;
    if ([self.mintextfield.text length]>0) {
        min = [self.mintextfield.text integerValue] ;
    }else{
        min = [self.mintextfield.placeholder integerValue] ;
    }
    
    if ([self.maxtextfield.text length]>0) {
        max = [self.maxtextfield.text integerValue] ;
    }else{
        max = [self.maxtextfield.placeholder integerValue] ;
    }

    if (min>max) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Set charge battery threshold value" message:[NSString stringWithFormat:@"Setting the battery charge threshold value error, the min:%ld > max:%ld",(long)min,(long)max] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] ;
        [alert show] ;
        return ;
    }
    
    if (min>100||min<0) {
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Set charge battery threshold value" message:[NSString stringWithFormat:@"Setting the battery charge threshold min value:%ld error",(long)min] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] ;
        [alert show] ;
        return ;
    }
    
    if (max<0||max>100) {
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Set charge battery threshold value" message:[NSString stringWithFormat:@"Setting the battery charge threshold max value:%ld error",(long)max] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] ;
        [alert show] ;
        
        return ;
    }
    
    [[Captuvo sharedCaptuvoDevice] setChargeBatteryThreshold:(int)min mx:(int)max] ;
    
    double delayInSeconds = .50;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [[Captuvo sharedCaptuvoDevice] enableBatteryQuery] ;
    });
}


- (IBAction)valueChanged:(id)sender
{
    UISwitch *switchbtn = (UISwitch*)sender ;
    if ([switchbtn isOn]) {
//        [[Captuvo sharedCaptuvoDevice] esdSecurityQuery:switchbtn.isOn];
    }else{
//        [[Captuvo sharedCaptuvoDevice] esdSecurityQuery:switchbtn.isOn];        
    }
}
- (IBAction)enablefirmware:(id)sender
{
    [[Captuvo sharedCaptuvoDevice] enableUpdateFirmware] ;
}
- (IBAction)disablefirmware:(id)sender
{
    [[Captuvo sharedCaptuvoDevice] disableUpdateFirmware] ;
}


#pragma mark ------------HID status, scan hard key delegate------------------

-(void)stateHID:(HIDCurStatus)status
{
    NSString *status_string = nil;
    switch (status) {
        case HIDActiveLock:
            status_string = @"HIDActiveLock" ; 
            break;
        case HIDActiveUnlock:
            status_string = @"HIDActiveUnlock" ;             
            break ;
        case HIDUnactiveLock:
            status_string = @"HIDUnactiveLock" ;                         
            break ;
        case HIDUnactiveUnlock:
            status_string = @"HIDUnactiveUnlock" ;                                     
            break ;
        default:
            break;
    }
    self.hid_scanKeystatus.textColor = [UIColor greenColor] ;
    self.hid_scanKeystatus.text = status_string ; 
}

- (void)scanKeyAction:(ScanKeyStatus)status
{
    NSString *scanKeyString = nil;
    switch (status) {
        case ScanKeyPressing:
            scanKeyString = @"ScanKeyPressing" ;
            break;
        case ScanKeyReleased:
            scanKeyString = @"ScanKeyReleased" ;             
            break ;
        default:
            break;
    }
    self.hid_scanKeystatus.textColor = [UIColor blackColor] ;
    self.hid_scanKeystatus.text = scanKeyString ;
}

#pragma mark Cupertino battery actions
//- (IBAction)batteryTypeQuery:(id)sender
//{
//    [[Captuvo sharedCaptuvoDevice] queryBatteryType] ;
//}
//
//- (IBAction)batteryAuthQuery:(id)sender
//{
//    [[Captuvo sharedCaptuvoDevice] queryBatteryAuthStatus] ; 
//}
- (IBAction)batteryDetailQuery:(id)sender
{
    [[Captuvo sharedCaptuvoDevice] queryBatteryDetailInfo] ;
}

//- (IBAction)setBatteryNotificationTime:(id)sender
//{
//    //set 60s for notification.
//    [self.notificationTimesfield resignFirstResponder] ;
//    NSInteger seconds = [self.notificationTimesfield.text integerValue];
//    [[Captuvo sharedCaptuvoDevice] setBatteryNotificationTime:seconds] ;
//}

- (IBAction)ledDefultScheme:(id)sender
{

    [[Captuvo sharedCaptuvoDevice] setLedScheme:YES];
}
- (IBAction)ledoTherScheme:(id)sender
{
    
    [[Captuvo sharedCaptuvoDevice] setLedScheme:NO];
}

-(void)responseLedScheme:(LedSchemeResponse*) status
{


     
     NSString * strScheme = [NSString stringWithFormat:@"%@", status.scheme == DefaultLedScheme? @"Default scheme " : @"Alternative scheme "];

    NSString *strConfigure = [NSString stringWithFormat:@"%@", status.bConfigSuccess ? @"Configure successfully" : @"Configure Fail"];
     

     NSString * result = [strScheme  stringByAppendingString:strConfigure];
     
    UIAlertView* alert = [[UIAlertView alloc]initWithTitle:nil
                                                            message:result
                                                           delegate:nil
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil];
    [alert show];
    
    return ;
 
}

- (IBAction)chargingSetting:(id)sender
{
    [self.startchargefield resignFirstResponder] ;
    [self.stopchargefield resignFirstResponder] ;
    [self.sledlimitpowerfield resignFirstResponder] ;
    cupertinoBatteryCharger *batteryCharger = [[cupertinoBatteryCharger alloc] init] ;
    batteryCharger.enable = YES ;
    batteryCharger.start = [self.startchargefield.text intValue] ;
    batteryCharger.stop = [self.stopchargefield.text intValue];
    batteryCharger.sledminLimitPower = [self.sledlimitpowerfield.text intValue];
    [[Captuvo sharedCaptuvoDevice] setBatteryChargingForAppleDevice:batteryCharger] ;
}

//- (IBAction)ChargingInfoQuery:(id)sender
//{
//    [[Captuvo sharedCaptuvoDevice] queryBatteryChargingStatus] ;
//}

//#pragma mark Cupertino battery delegate methods
//-(void)	responseBatteryType:(NSInteger)Type
//{
//    self.currentBatteryTypelbl.text = [NSString stringWithFormat:@"%ld",(long)Type] ;
//}
//
///**
// @brief This method is response delegate method for query battery authenticate status.
// 
// When battery protocol ready, It is required by the method as below:<em>-(void) queryBatteryAuthStatus</em> this delegate method will be called
// */
//-(void) responseBatteryAuthStatus:(BOOL)status
//{
//    self.BatteryAuthlbl.text = [NSString stringWithFormat:@"%@", status ? @"This battery already Authenticate" : @"This battery hasn't Authenticate"] ;
//}
/**
 @brief This method is response delegate method for query battery detail information.
 Valid data:0/1 -provide if the Cupertino battery is valid or not.
 Percentage:2 Btye -provide the current Cupertino battery percentage
 Remaining Capacity mAh:2Btye -provide the Cupertino battery current remaining capacity
 Total Capacity mAh:2Btye -provide the Cupertino battery total capacity.
 Temperture:2Byte -provide the Cupertino battery temperure.
 Voltage:2Byte -provide the Cupertino battery current voltage.
 
 When battery protocol ready, It is required by the method as below:<em>-(void) queryBatteryDetailInfo</em> this delegate method will be called
 */
-(void) responseBatteryDetailInformation:(cupertinoBatteryDetailInfo*)batteryInfo
{
    NSString *valid = nil ;
    if (batteryInfo.valid) {
        valid = @"This battery is valid" ;
    }else{
        valid = @"This battery is unvalid" ;
    }
    
    self.batterydetailInfolbl.text = [NSString stringWithFormat:@"%@ percentage:%d remain capactiy:%d total capacity:%d temperture:%0.1lf voltage:%0.3lf",valid,batteryInfo.percentage,batteryInfo.remainCapacity,batteryInfo.totalCapacity,batteryInfo.temperture, batteryInfo.voltage] ;
}

- (void)responseHIDTimeout:(NSInteger)timeout
{
    self.timeoutvaluelbl.text = [NSString stringWithFormat:@"timeout:%ld",(long)timeout] ;
}

- (void)responseHIDChangedDetail:(NSString *)changedInfo
{
    self.timeoutvaluelbl.text = [NSString stringWithFormat:@"HIDChanged:%@",changedInfo] ; 
}
///**
// @brief This method is response delegate method for battery notification post to iOS device.
// 
// When battery protocol ready, It is required by the method as below:<em>-(void) setBatteryNotificationTime:(NSInteger)seconds;</em> is called, after seconds this delegate method will be called.
// 
// The notification received current battery detail information.
// Valid data:0/1 -provide if the Cupertino battery is valid or not.
// Percentage:2 Btye -provide the current Cupertino battery percentage
// Remaining Capacity mAh:2Btye -provide the Cupertino battery current remaining capacity
// Total Capacity mAh:2Btye -provide the Cupertino battery total capacity.
// Temperture:2Byte -provide the Cupertino battery temperure.
// Voltage:2Byte -provide the Cupertino battery current voltage.
// */
//-(void) responseBatteryInformationFromNotification:(cupertinoBatteryDetailInfo*)batteryInfo
//{
//
//    NSString *valid = nil ;
//    if (batteryInfo.valid) {
//        valid = @"This battery is valid" ;
//    }else{
//        valid = @"This battery is unvalid" ;
//    }
//    
//    self.batterydetailInfolbl.text = [NSString stringWithFormat:@"This is notification battery detail information\n%@\npercentage:%d\nremain capactiy:%d\ntotal capacity:%d\ntemperture:%0.1lf\nvoltage:%0.3lf",valid,batteryInfo.percentage,batteryInfo.remainCapacity,batteryInfo.totalCapacity,batteryInfo.temperture, batteryInfo.voltage] ;
//
//
//}
///**
// @brief This method is response delegate method for query battery charging status.
// 
// When battery protocol ready, It is required by the method as below:<em>-(void) queryBatteryChargingStatus</em> is called,this delegate method will be called
// The cupertinoBatteryCharging information as below:
// isExternalPowerPlugin:0/1 -Cupertino has been plugined by external power or not.
// isChargingforCupertino:0/1 -External pwer charging for Cupertino or not.
// //isChargingforAppledevice:0/1 -Cupertino is charging for Apple device or not.
// reserved:0/1 -This byte reserved, that will be used.
// */
//-(void)	responseBatteryCharging:(cupertinoBatteryChargingInfo*)chargingInfo
//{
//    NSString *valid = nil ;
//    if (chargingInfo.isExternalPowerPlugin) {
//        valid = @"External charging" ;
//    }else{
//        valid = @"UnExternal charging" ;
//    }
//    NSString *chargingforCupertino = nil;
//    if (chargingInfo.isChargingforCupertino) {
//        chargingforCupertino = @"Charging" ;
//    }else {
//        chargingforCupertino = @"Uncharging" ;
//    }
//    self.charginginfolbl.text = [NSString stringWithFormat:@"%@ %@",valid,chargingforCupertino] ;
//
//}

- (IBAction)enableTriggerKey:(id)sender
{
      [[Captuvo sharedCaptuvoDevice] enableTriggerKey];
    
    TriggerKeyStatus setStatus = [[Captuvo sharedCaptuvoDevice] requestTriggerKeyStatus];
    
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Trigger key Status "
                                                        message:[NSString stringWithFormat:@"%@",((setStatus == 0 ) ? @"Enabled":@"Disabled")]
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
    [alertView show];

}

- (IBAction)disableTriggerKey:(id)sender
{
      [[Captuvo sharedCaptuvoDevice] disableTriggerKey];
    
    TriggerKeyStatus setStatus = [[Captuvo sharedCaptuvoDevice] requestTriggerKeyStatus];
    
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Trigger key Status "
                                                        message:[NSString stringWithFormat:@"%@",((setStatus == 0 ) ? @"Enabled":@"Disabled")]
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
    [alertView show];

}



#pragma mark --------text field delegate--------
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (isPad) {
        if (self.scrolview.contentOffset.y<800) {
            self.scrolview.contentOffset = CGPointMake(0, 800) ;
        }
    }else{
        if (self.scrolview.contentOffset.y<600) {
            self.scrolview.contentOffset = CGPointMake(0, 600) ;
        }
    }
}

-(void)captuvoConnected{
    
    [[Captuvo sharedCaptuvoDevice] startPMHardware] ;
}


-(void)captuvoDisconnected{
    
     [[Captuvo sharedCaptuvoDevice] stopPMHardware] ;
}

- (IBAction)getFirmwareHeaderAction:(id)sender
{
//    [[Captuvo sharedCaptuvoDevice] ] ;
}

- (IBAction)queryHIDTimeoutAction:(id)sender{
    [self.timetextfield resignFirstResponder] ;
    [[Captuvo sharedCaptuvoDevice] queryHIDTimeout] ;
}
- (IBAction)setHIDTimeoutAction:(id)sender
{
    [self.timetextfield resignFirstResponder] ;     
    NSString *timevalue = self.timetextfield.text ;
    
    [[Captuvo sharedCaptuvoDevice]
     setHIDTimeout:[timevalue intValue]] ;
}


@end
