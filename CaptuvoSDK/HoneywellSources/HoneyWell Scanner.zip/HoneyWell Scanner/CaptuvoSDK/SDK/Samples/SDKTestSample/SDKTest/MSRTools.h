//
//  MSRTools.h
//  Honeywell_SDK
//
//  Created by Edward Finegan on 6/12/12.
//  Copyright (c) 2012 Dryrain Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Captuvo.h"

@interface MSRTools : NSObject

+(Byte)checksumForData:(NSData*)data;

+(TrackSelection)trackSelectionWithByteCode:(Byte)byteCode;
+(NSString*)trackSelectionName:(TrackSelection)trackSelection;

+(SecurityLevel)securityLevelWithByteCode:(Byte)byteCode;
+(NSString*)securityLevelName:(SecurityLevel)securityLevel;
@end
