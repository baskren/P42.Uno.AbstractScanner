//
//  DecoderTools.h
//  Honeywell_SDK
//
//  Created by Edward Finegan on 6/15/12.
//  Copyright (c) 2012 Dryrain Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Captuvo.h"

@interface DecoderTools : NSObject
+(Byte)lookUpSymbologyCode:(Symbology)symbology;
+(Symbology)lookUpSymbologyFromCode:(Byte)code;
+(NSString*)symbologyName:(Symbology)symbology;
@end
