//
//  AppDelegate.h
//  iCharging
//
//  Created by zhou shadow on 3/18/13.
//  Copyright (c) 2015 Honeywell Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    UINavigationController *navigationController ;
}
@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;
@end
