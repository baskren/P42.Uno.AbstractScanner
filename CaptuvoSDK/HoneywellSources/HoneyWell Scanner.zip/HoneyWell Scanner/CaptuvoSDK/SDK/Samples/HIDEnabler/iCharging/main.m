//
//  main.m
//  iCharging
//
//  Created by zhou shadow on 3/18/13.
//  Copyright (c) 2015 Honeywell Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
