//
//  ChargingViewController.h
//  iCharging
//
//  Created by zhou shadow on 3/18/13.
//  Copyright (c) 2015 Honeywell Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChargingViewController : UIViewController<UITextFieldDelegate>


@property (nonatomic,strong) IBOutlet UIButton *ActivateButton ;
@property (nonatomic,strong) IBOutlet UIButton *DeactivateButton ;


@property (nonatomic,strong) IBOutlet UITextField *textField ;
@property (nonatomic,strong) IBOutlet UILabel *versionlabel ;
@property (nonatomic,strong) IBOutlet UILabel *instructionlbl ;


- (IBAction)ActivateHID:(id)sender;
- (IBAction)DeactivateHID:(id)sender;

@end
