//
//  ChargingViewController.m
//  iCharging
//
//  Created by zhou shadow on 3/18/13.
//  Copyright (c) 2015 Honeywell Inc. All rights reserved.
//

#import "ChargingViewController.h"
#import "Captuvo.h"
@interface ChargingViewController ()<CaptuvoEventsProtocol>
@property (nonatomic,assign)  bool  HIDEnable;

- (void)UpdateButtonsStatus;

@end

@implementation ChargingViewController
@synthesize ActivateButton = _ActivateButton ;
@synthesize DeactivateButton = _DeactivateButton ;


@synthesize HIDEnable = _HIDEnable;

@synthesize textField = _textField ;
@synthesize versionlabel = _versionlabel ;
@synthesize instructionlbl = _instructionlbl ;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization

    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [[Captuvo sharedCaptuvoDevice] startPMHardware] ;
    [[Captuvo sharedCaptuvoDevice] addCaptuvoDelegate:self] ;
    
    self.title = @"iSled HIDEnabler" ;
    
    self.HIDEnable = NO;
    [self UpdateButtonsStatus];
    
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString *)kCFBundleVersionKey];
    self.versionlabel.numberOfLines = 0 ;
    self.versionlabel.lineBreakMode = NSLineBreakByWordWrapping;
    self.versionlabel.text = [NSString stringWithFormat:@"sdk version:%@\napp version:%@",[[Captuvo sharedCaptuvoDevice] getSDKfullVersion],version] ;
    
    self.ActivateButton.hidden = YES;
    
    self.DeactivateButton.hidden = YES;
}

- (void)UpdateButtonsStatus
{
    
    if(self.HIDEnable )
    {
        [self.ActivateButton setBackgroundImage:[UIImage imageNamed:@"disablebg"] forState:UIControlStateNormal] ;
        
        [self.DeactivateButton setBackgroundImage:[UIImage imageNamed:@"enablebg"] forState:UIControlStateNormal] ;
    }
    else{
        [self.ActivateButton setBackgroundImage:[UIImage imageNamed:@"enablebg"] forState:UIControlStateNormal] ;
        
        [self.DeactivateButton setBackgroundImage:[UIImage imageNamed:@"disablebg"] forState:UIControlStateNormal] ;
    }
    
}
- (IBAction)ActivateHID:(id)sender
{

     [[Captuvo sharedCaptuvoDevice] unLockHIDMode] ;
     [[Captuvo sharedCaptuvoDevice] activateHID] ;
     [[Captuvo sharedCaptuvoDevice] lockHIDMode] ;
    
    self.HIDEnable = YES;
    
    [self UpdateButtonsStatus];
    [[Captuvo sharedCaptuvoDevice] requestHIDStatus];
}

- (IBAction)DeactivateHID:(id)sender
{
     [[Captuvo sharedCaptuvoDevice] unLockHIDMode] ;
     [[Captuvo sharedCaptuvoDevice] deActivateHID] ;
     [[Captuvo sharedCaptuvoDevice] lockHIDMode] ;
    
    self.HIDEnable = NO;
    
    [self UpdateButtonsStatus];
    [[Captuvo sharedCaptuvoDevice] requestHIDStatus];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    // enter closes the keyboard
    if ([string isEqualToString:@"\n"])
    {
        [textField resignFirstResponder];
        return NO;
    }
    return YES;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)stateHID:(HIDCurStatus)status
{
    
    NSString *strHidStatus = nil;
    if((status == HIDActiveLock)|| (status == HIDActiveUnlock))
    {
       self.HIDEnable = YES;
       strHidStatus = @"HID Status: Activate\n";
       
    }
    else if((status == HIDUnactiveLock)|| (status == HIDUnactiveUnlock))
    {
      self.HIDEnable = NO;
          strHidStatus = @"HID Status: Deactivate\n";
    }
    
     self.ActivateButton.hidden = NO;
     self.DeactivateButton.hidden = NO;
    
    [self UpdateButtonsStatus];
    
    
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString *)kCFBundleVersionKey];
    self.versionlabel.numberOfLines = 0 ;
    self.versionlabel.lineBreakMode = NSLineBreakByWordWrapping;
    
    self.versionlabel.text = [strHidStatus stringByAppendingString:[NSString stringWithFormat:@"sdk version:%@\napp version:%@",[[Captuvo sharedCaptuvoDevice] getSDKfullVersion],version] ];


}

-(void)captuvoConnected
{
    [[Captuvo sharedCaptuvoDevice] startPMHardware] ;
}

- (void)pmReady
{
 
    [[Captuvo sharedCaptuvoDevice] requestHIDStatus];
    
    // Do any additional setup after loading the view from its nib.
    
        self.instructionlbl.text = @"To Open or Close HID function the steps:\n 1.Click \"Deactivate\" to close HID.\n 2.Click \"Activate\" open HID mode." ;
      self.instructionlbl.numberOfLines= 0 ;
    self.instructionlbl.lineBreakMode =NSLineBreakByWordWrapping ;
    

}

@end
