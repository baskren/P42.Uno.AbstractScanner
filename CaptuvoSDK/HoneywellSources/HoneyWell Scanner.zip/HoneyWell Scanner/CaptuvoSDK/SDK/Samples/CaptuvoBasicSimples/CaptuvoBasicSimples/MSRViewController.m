//
//  SecondViewController.m
//  CaptuvoBasicSimples
//
//  Created by zhou shadow on 4/20/15.
//  Copyright (c) 2015 Honeywell Inc. All rights reserved.
//

#import "MSRViewController.h"

@interface MSRViewController ()

@end

@implementation MSRViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateMSRUI:) name:MSR_DATA_RECEIVED_VC object:nil] ;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)updateMSRUI:(NSNotification *)notification
{
    if (notification.object!=nil&&[notification.object isKindOfClass:[NSString class]]) {
        self.swipemsrlbl.text = notification.object ;
    }
}

@end
