//
//  ConstDefine.h
//  CaptuvoBasicSimples
//
//  Created by zhou shadow on 4/21/15.
//  Copyright (c) 2015 Honeywell Inc. All rights reserved.
//

#ifndef CaptuvoBasicSimples_ConstDefine_h
#define CaptuvoBasicSimples_ConstDefine_h
#define DECODER_DATA_RECEIVED_VC @"decoderReceivedDataFORViewController"
#define MSR_DATA_RECEIVED_VC @"MSRReceivedDataFORViewController"
#define PM_DATA_RECEIVED_VC @"PMReceivedDataFORViewController"
#endif
