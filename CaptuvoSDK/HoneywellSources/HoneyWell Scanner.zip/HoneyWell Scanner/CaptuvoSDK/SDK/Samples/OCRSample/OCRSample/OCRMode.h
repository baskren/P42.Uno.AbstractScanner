//
//  NSObject+OCRMode.h
//  OCRDemo
//
//  Created by Andy on 15-3-13.
//  Copyright (c) 2015 Honeywell Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Captuvo.h"

@interface OCRMode: NSObject<CaptuvoEventsProtocol>

typedef enum
{
    
    UNDefine,
    LICENSED,
    UNLICENSED
    
}licenseStatus;

/**
 @brief Enumeration for the OCR templete setting
 */
typedef enum
{
    
    DEFAULT,
    PASSPORT,
    ISBN,
    PRICEFIELD,
    MICRE13B
    
}OCRTempleteSetting;


@property (nonatomic,assign) licenseStatus ocrLicenseStatus ;
@property (nonatomic,strong) NSMutableArray *configArray ;

- (void)initOCRConfigure;
+(OCRMode*)sharedOCRMode;
- (void)ParseOcrLicenseinThroughData:(NSData *)data;
@end
